class LoginPage{
navigate(){
    cy.visit("https://buger-eats.vercel.app/")
    cy.xpath('//a[@href="/deliver"]').click()

}



name(){
    return cy.xpath('//input[@name="name"]')
}
cpf(){
    return cy.xpath('//input[@name="cpf"]')
}
email(){
    return cy.xpath('//input[@name="email"]')
}
whatsapp(){
    return cy.xpath('//input[@name="whatsapp"]')
}
postalcode(){
    return cy.xpath('//input[@name="postalcode"]')
}
cep(){
    return cy.xpath('//input[@value="Buscar CEP"]')
}
addressnumber(){
    return cy.xpath('//input[@name="address-number"]')
}
vehicle(){
    return cy.xpath('//img[@alt="Van/Carro"]')
}
dropzone(){
    return cy.xpath('//div[@class="dropzone"]')
}
buttonSuccess(){
    return cy.xpath('//button[@class="button-success"]')
}
confirm(){
    return cy.xpath('//div[@class="swal2-popup swal2-modal swal2-icon-success swal2-show"]')
}

alert(){
    return cy.xpath('//span[@class="alert-error"]')
}

}

export default LoginPage