/// cypress/support/commands.js

import 'cypress-file-upload'
import LoginPage from '../support/pages/LoginPage'
/// <reference types="cypress"/>

describe('Challenge 1',() =>{
    const login = new LoginPage()

it ('Invalid CPF', () =>{
login.navigate();
login.cpf().type('9999999')
login.buttonSuccess().click
login.alert().should('contain','Oops! CPF inválido')

})
it ('Invalid Driver License', () =>{
    login.navigate();
    login.buttonSuccess().click
    login.alert().should('contain','Adicione uma foto da sua CNH')
})

it ('Success Registration', () =>{
    login.navigate();
    login.name().type('Sample Name')
    login.cpf().type('09588628423')
    login.email().type('example@example.com')
    login.whatsapp().type('99123456789')
    login.postalcode().type('52221-250')
    login.cep().click()
    login.addressnumber().type('99')
    login.vehicle().click()
    login.dropzone().attachFile('cnh.jpg', { subjectType: 'drag-n-drop' });
    login.buttonSuccess().click
    login.confirm().should('contain','Aí Sim...')
    })
})


describe('Challenge 2',() =>{



    it ('Contact us', () =>{

 

    cy.visit("https://webdriveruniversity.com/IFrame/")
    cy.get('#frame')
    .should('be.visible')
    .should('not.be.empty')
    .then(($iframe) => {
        const $body = $iframe.contents().find('body')

    cy.wrap($body)
    .find('a[href="../Contact-Us/contactus.html"]')
    .click()
})
cy.get('#frame')
    .should('be.visible')
    .should('not.be.empty')
    .then(($iframe) => {
        const $body = $iframe.contents().find('body')
    cy.wrap($body)
    .find('//*[@id="contact_form"]/input[1]')
    .type('Cypress{Teste}')

    cy.wrap($body)
    .find(`input[name='last_name']`)
    .type('Cypress{Testea}')

    cy.wrap($body)
    .find(`input[name='email']`)
    .type('Cypress{Testeaaa}')

    cy.wrap($body)
    .find(`input[name='message']`)
    .type('Cypress{Testasdasdasde}')

    cy.get('//*[@id="contact_reply"]/h1').should('be.visible')

})

    
    

    
    

})
    
    })

    